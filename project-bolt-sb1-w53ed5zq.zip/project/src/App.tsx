import React from 'react';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Performance from './components/Performance';
import Team from './components/Team';
import Testimonials from './components/Testimonials';
import News from './components/News';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <HelmetProvider>
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
        <Helmet>
          <title>Equinox Investments | Professional Investment Solutions</title>
          <meta name="description" content="Equinox Investments offers professional investment solutions to help you grow your wealth and secure your financial future." />
        </Helmet>
        <Navbar />
        <main>
          <Hero />
          <Services />
          <Performance />
          <Team />
          <Testimonials />
          <News />
          <Contact />
        </main>
        <Footer />
      </div>
    </HelmetProvider>
  );
}

export default App;