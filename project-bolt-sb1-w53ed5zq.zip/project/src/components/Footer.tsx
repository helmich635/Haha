import React from 'react';
import { DollarSign, Facebook, Twitter, Linkedin, Instagram, ChevronRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto pt-16 pb-8 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-4">
              <DollarSign className="h-8 w-8 text-emerald-400" />
              <span className="ml-2 text-xl font-bold text-white">Equinox Investments</span>
            </div>
            <p className="mb-4">
              Professional investment solutions tailored to help you achieve your financial goals with confidence.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white mb-4">Services</h3>
            <ul className="space-y-2">
              {[
                'Stock Market Investments',
                'Mutual Funds',
                'Real Estate Investment',
                'Retirement Planning',
                'Private Equity',
                'Algorithmic Trading',
              ].map((service, index) => (
                <li key={index}>
                  <a href="#services" className="hover:text-emerald-400 transition-colors flex items-center">
                    <ChevronRight className="h-3 w-3 mr-1" />
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { name: 'About Us', href: '#' },
                { name: 'Our Team', href: '#team' },
                { name: 'Performance', href: '#performance' },
                { name: 'Investment Insights', href: '#news' },
                { name: 'Testimonials', href: '#' },
                { name: 'Contact Us', href: '#contact' },
              ].map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="hover:text-emerald-400 transition-colors flex items-center">
                    <ChevronRight className="h-3 w-3 mr-1" />
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white mb-4">Newsletter</h3>
            <p className="mb-4">
              Subscribe to our newsletter for the latest investment insights and market updates.
            </p>
            <form className="space-y-3">
              <div>
                <input
                  type="email"
                  placeholder="Your email address"
                  className="w-full px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all text-white"
                />
              </div>
              <button
                type="submit"
                className="w-full px-4 py-2 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-slate-400">
              &copy; {new Date().getFullYear()} Equinox Investments. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                Disclosures
              </a>
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-4 text-center md:text-left">
            Investment advisory services offered through Equinox Investments, a registered investment advisor. 
            Past performance does not guarantee future results. Investments involve risk and are not FDIC insured.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;