import React, { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    content:
      "Equinox Investments has transformed our approach to retirement planning. Their personalized strategies and regular portfolio reviews have given us confidence in our financial future.",
    author: "Robert & Susan Thompson",
    role: "Retired Professionals",
    image: "https://images.pexels.com/photos/5704849/pexels-photo-5704849.jpeg?auto=compress&cs=tinysrgb&w=600",
    rating: 5,
  },
  {
    id: 2,
    content:
      "As a business owner, I needed an investment partner who understood my unique financial situation. The team at Equinox created a diversified portfolio that balances growth with security.",
    author: "James Wilson",
    role: "CEO, TechSolutions Inc.",
    image: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=600",
    rating: 5,
  },
  {
    id: 3,
    content:
      "I've been investing with Equinox for over 5 years and have seen consistent returns even during market downturns. Their risk management approach is truly exceptional.",
    author: "Dr. Elena Rodriguez",
    role: "Medical Professional",
    image: "https://images.pexels.com/photos/5225463/pexels-photo-5225463.jpeg?auto=compress&cs=tinysrgb&w=600",
    rating: 5,
  },
  {
    id: 4,
    content:
      "Starting my investment journey was intimidating until I found Equinox. Their educational approach and transparent communication made me feel confident in every decision.",
    author: "Thomas Chen",
    role: "Software Engineer",
    image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=600",
    rating: 5,
  },
  {
    id: 5,
    content:
      "The algorithmic trading strategies at Equinox have delivered returns that consistently outperform traditional approaches. Their data-driven methodology is truly impressive.",
    author: "Sarah Patel",
    role: "Data Scientist",
    image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600",
    rating: 5,
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const nextTestimonial = () => {
    setDirection(1);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setDirection(-1);
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-20 bg-slate-900 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-20 left-20 w-64 h-64 bg-emerald-500 rounded-full filter blur-3xl opacity-10"></div>
      <div className="absolute bottom-20 right-20 w-64 h-64 bg-blue-500 rounded-full filter blur-3xl opacity-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <Quote className="h-12 w-12 text-emerald-400 mx-auto mb-4 opacity-50" />
          <h2 className="text-3xl md:text-4xl font-bold text-white">
            What Our Clients Say
          </h2>
          <p className="mt-4 text-xl text-slate-300 max-w-3xl mx-auto">
            Don't just take our word for it. Hear from our satisfied clients about their investment journey with us.
          </p>
        </div>

        <div className="relative">
          <div className="relative overflow-hidden py-10">
            <div
              className={`transition-transform duration-500 ease-in-out flex`}
              style={{
                transform: `translateX(-${currentIndex * 100}%)`,
              }}
            >
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="min-w-full px-4"
                >
                  <div className="bg-white rounded-2xl shadow-xl p-8 md:p-10 max-w-4xl mx-auto">
                    <div className="flex flex-col md:flex-row gap-8">
                      <div className="md:w-1/3">
                        <img
                          src={testimonial.image}
                          alt={testimonial.author}
                          className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover mx-auto md:mx-0"
                        />
                      </div>
                      <div className="md:w-2/3">
                        <div className="flex mb-4">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star key={i} className="h-5 w-5 text-amber-400 fill-amber-400" />
                          ))}
                        </div>
                        <blockquote className="text-lg md:text-xl text-slate-700 italic mb-6">
                          "{testimonial.content}"
                        </blockquote>
                        <div>
                          <p className="font-bold text-slate-900">{testimonial.author}</p>
                          <p className="text-slate-500">{testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation controls */}
          <div className="flex justify-center mt-8 gap-4">
            <button
              onClick={prevTestimonial}
              className="p-2 rounded-full bg-slate-700 text-white hover:bg-emerald-600 transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setDirection(index > currentIndex ? 1 : -1);
                    setCurrentIndex(index);
                  }}
                  className={`h-2 rounded-full transition-all ${
                    currentIndex === index
                      ? 'w-8 bg-emerald-500'
                      : 'w-2 bg-slate-600 hover:bg-slate-400'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            <button
              onClick={nextTestimonial}
              className="p-2 rounded-full bg-slate-700 text-white hover:bg-emerald-600 transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {[
            { label: 'Happy Clients', value: '1,500+' },
            { label: 'Average Client Rating', value: '4.9/5' },
            { label: 'Client Retention Rate', value: '94%' },
          ].map((stat, index) => (
            <div key={index} className="p-6 bg-slate-800/50 backdrop-blur-sm rounded-xl">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-slate-300">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;