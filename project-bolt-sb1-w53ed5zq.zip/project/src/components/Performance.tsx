import React from 'react';
import { TrendingUp, LineChart, BarChart3, ArrowUpRight } from 'lucide-react';

const performanceData = [
  {
    portfolio: 'Conservative',
    returns: [
      { year: '2020', value: 8.3 },
      { year: '2021', value: 11.5 },
      { year: '2022', value: 5.1 },
      { year: '2023', value: 9.4 },
      { year: '2024', value: 10.1 },
    ],
    color: 'bg-blue-500',
  },
  {
    portfolio: 'Balanced',
    returns: [
      { year: '2020', value: 12.1 },
      { year: '2021', value: 16.3 },
      { year: '2022', value: 7.2 },
      { year: '2023', value: 14.7 },
      { year: '2024', value: 15.3 },
    ],
    color: 'bg-emerald-500',
  },
  {
    portfolio: 'Growth',
    returns: [
      { year: '2020', value: 19.7 },
      { year: '2021', value: 23.4 },
      { year: '2022', value: 9.8 },
      { year: '2023', value: 21.2 },
      { year: '2024', value: 23.6 },
    ],
    color: 'bg-amber-500',
  },
];

const Performance = () => {
  return (
    <section id="performance" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-slate-200 text-slate-700 mb-4">
            <TrendingUp className="h-4 w-4 mr-2" />
            <span>Proven track record</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
            Our Investment Performance
          </h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Track record of consistent returns across different market conditions and investment strategies.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-2xl shadow-lg p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-emerald-50 w-32 h-32 rounded-full -mr-16 -mt-16"></div>
            <div className="relative">
              <h3 className="text-2xl font-bold text-slate-800 mb-6 flex items-center">
                <LineChart className="h-6 w-6 text-emerald-600 mr-2" />
                Portfolio Performance
              </h3>
              
              <div className="space-y-8">
                {performanceData.map((portfolio, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium text-slate-700">{portfolio.portfolio} Portfolio</h4>
                      <div className="flex items-center text-emerald-600 font-medium">
                        <span>+{portfolio.returns[portfolio.returns.length - 1].value}%</span>
                        <ArrowUpRight className="h-4 w-4 ml-1" />
                      </div>
                    </div>
                    <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${portfolio.color} rounded-full`} 
                        style={{ width: `${portfolio.returns[portfolio.returns.length - 1].value * 3}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500">
                      {portfolio.returns.map((yearData, yearIndex) => (
                        <div key={yearIndex} className="text-center">
                          <div className="font-medium">{yearData.year}</div>
                          <div className="text-emerald-600">+{yearData.value}%</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 pt-6 border-t border-slate-100">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium text-slate-800">Market Comparison</h4>
                    <p className="text-sm text-slate-500">Outperforming market average by</p>
                  </div>
                  <div className="text-2xl font-bold text-emerald-600">+7.3%</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                title: 'Assets Under Management',
                value: '$1.8B+',
                subtitle: 'Total client investments',
                icon: <BarChart3 className="h-6 w-6 text-emerald-600" />,
                color: 'bg-emerald-50',
                metric: '↑ 23% from last year',
              },
              {
                title: 'Client Return Rate',
                value: '94%',
                subtitle: 'Clients who reinvest',
                icon: <TrendingUp className="h-6 w-6 text-blue-600" />,
                color: 'bg-blue-50',
                metric: '↑ 7% from last year',
              },
              {
                title: 'Average Annual Return',
                value: '15.7%',
                subtitle: 'Across all portfolios',
                icon: <LineChart className="h-6 w-6 text-amber-600" />,
                color: 'bg-amber-50',
                metric: '↑ 3.2% from last year',
              },
              {
                title: 'Risk-Adjusted Performance',
                value: 'Top 5%',
                subtitle: 'Industry ranking',
                icon: <BarChart3 className="h-6 w-6 text-indigo-600" />,
                color: 'bg-indigo-50',
                metric: 'Consistent for 5+ years',
              },
            ].map((stat, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-md p-6 relative overflow-hidden group hover:shadow-lg transition-shadow"
              >
                <div className={`absolute top-0 right-0 w-24 h-24 ${stat.color} rounded-full -mr-10 -mt-10 opacity-70 transition-transform group-hover:scale-110`}></div>
                <div className="relative">
                  <div className={`p-2 rounded-lg ${stat.color} inline-block mb-3`}>
                    {stat.icon}
                  </div>
                  <h4 className="text-lg font-medium text-slate-700">{stat.title}</h4>
                  <div className="mt-2 text-3xl font-bold text-slate-900">{stat.value}</div>
                  <p className="text-sm text-slate-500 mt-1">{stat.subtitle}</p>
                  <div className="mt-4 text-xs font-medium text-emerald-600">{stat.metric}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <a
            href="#contact"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"
          >
            Get Your Personalized Performance Analysis
          </a>
        </div>
      </div>
    </section>
  );
};

export default Performance;