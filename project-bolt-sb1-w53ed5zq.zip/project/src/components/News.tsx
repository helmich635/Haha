import React from 'react';
import { Calendar, ArrowRight, TrendingUp, DollarSign, Globe } from 'lucide-react';

const newsItems = [
  {
    title: 'Global Markets Outlook 2025: Navigating New Opportunities',
    excerpt: 'Our analysis of emerging market trends and investment opportunities for the coming year.',
    date: 'Nov 15, 2024',
    category: 'Market Analysis',
    icon: <Globe className="h-5 w-5" />,
    image: 'https://images.pexels.com/photos/7567434/pexels-photo-7567434.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    title: 'The Impact of Artificial Intelligence on Investment Strategies',
    excerpt: 'How AI and machine learning are transforming the landscape of modern investing.',
    date: 'Oct 28, 2024',
    category: 'Technology',
    icon: <TrendingUp className="h-5 w-5" />,
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    title: 'Sustainable Investing: Performance and Environmental Impact',
    excerpt: 'Our latest research on ESG investments and their financial performance metrics.',
    date: 'Oct 12, 2024',
    category: 'ESG Investing',
    icon: <DollarSign className="h-5 w-5" />,
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

const News = () => {
  return (
    <section id="news\" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
            Latest Market Insights
          </h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Stay informed with our latest research, market analysis, and investment strategies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow group"
            >
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium bg-white/80 backdrop-blur-sm text-slate-800 flex items-center">
                  {item.icon}
                  <span className="ml-1">{item.category}</span>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-slate-500 mb-3">
                  <Calendar className="h-4 w-4 mr-1" />
                  {item.date}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-emerald-600 transition-colors">
                  {item.title}
                </h3>
                <p className="text-slate-600 mb-4">{item.excerpt}</p>
                <a
                  href="#"
                  className="inline-flex items-center text-emerald-600 font-medium hover:text-emerald-700 transition-colors"
                >
                  Read more
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-emerald-50 rounded-2xl p-8 md:p-12">
          <div className="md:grid md:grid-cols-2 md:gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">
                Subscribe to Our Investment Newsletter
              </h3>
              <p className="text-slate-600 mb-6">
                Get the latest market insights, investment strategies, and financial news delivered directly to your inbox.
              </p>
              <form className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    placeholder="Enter your email"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
                <div className="flex items-start">
                  <input
                    id="privacy"
                    type="checkbox"
                    className="h-4 w-4 mt-1 text-emerald-600 focus:ring-emerald-500 border-slate-300 rounded"
                  />
                  <label htmlFor="privacy" className="ml-2 block text-sm text-slate-500">
                    I agree to receive investment insights and understand I can unsubscribe at any time.
                  </label>
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors w-full"
                >
                  Subscribe Now
                </button>
              </form>
            </div>
            <div className="mt-8 md:mt-0 flex justify-center">
              <div className="bg-white p-6 rounded-xl shadow-md max-w-sm">
                <h4 className="font-medium text-slate-800 mb-4">Recent Webinars</h4>
                <ul className="space-y-4">
                  {[
                    { title: 'Retirement Planning Strategies for 2025', date: 'Dec 10, 2024' },
                    { title: 'Real Estate vs. Stocks: Investment Comparison', date: 'Nov 22, 2024' },
                    { title: 'Tax-Efficient Investment Approaches', date: 'Nov 05, 2024' },
                  ].map((webinar, webinarIndex) => (
                    <li key={webinarIndex} className="border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                      <a href="#" className="group">
                        <h5 className="font-medium text-slate-700 group-hover:text-emerald-600 transition-colors">
                          {webinar.title}
                        </h5>
                        <p className="text-sm text-slate-500 mt-1">{webinar.date}</p>
                      </a>
                    </li>
                  ))}
                </ul>
                <a
                  href="#"
                  className="mt-4 inline-flex items-center text-sm text-emerald-600 font-medium hover:text-emerald-700 transition-colors"
                >
                  View all webinars
                  <ArrowRight className="ml-1 h-3 w-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default News;