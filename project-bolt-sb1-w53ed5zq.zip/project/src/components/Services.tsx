import React from 'react';
import { TrendingUp, PieChart, Building as Buildings, Briefcase, Users, BarChart } from 'lucide-react';

const services = [
  {
    icon: <TrendingUp className="h-10 w-10 text-emerald-600" />,
    title: 'Stock Market Investments',
    description:
      'Strategically invest in carefully selected stocks across various markets and sectors for long-term growth and dividends.',
    features: ['Diversified portfolios', 'Dividend-focused options', 'Growth-oriented strategies'],
  },
  {
    icon: <PieChart className="h-10 w-10 text-emerald-600" />,
    title: 'Mutual Funds',
    description:
      'Access professionally managed funds with diversified holdings to balance risk and return based on your goals.',
    features: ['Low minimum investment', 'Professional management', 'Automatic diversification'],
  },
  {
    icon: <Buildings className="h-10 w-10 text-emerald-600" />,
    title: 'Real Estate Investment',
    description:
      'Invest in property markets through REITs and funds without the complexities of direct ownership.',
    features: ['Commercial & residential exposure', 'Regular income generation', 'Inflation hedge'],
  },
  {
    icon: <Briefcase className="h-10 w-10 text-emerald-600" />,
    title: 'Retirement Planning',
    description:
      'Secure your future with tax-advantaged retirement accounts and long-term investment strategies.',
    features: ['Tax optimization', 'Long-term growth focus', 'Regular rebalancing'],
  },
  {
    icon: <Users className="h-10 w-10 text-emerald-600" />,
    title: 'Private Equity',
    description:
      'Access exclusive investment opportunities in private companies with high growth potential.',
    features: ['High-growth potential', 'Exclusive opportunities', 'Professional oversight'],
  },
  {
    icon: <BarChart className="h-10 w-10 text-emerald-600" />,
    title: 'Algorithmic Trading',
    description:
      'Leverage cutting-edge algorithms and AI to identify market opportunities with precision and speed.',
    features: ['Data-driven decisions', '24/7 market monitoring', 'Rapid execution'],
  },
];

const Services = () => {
  return (
    <section id="services\" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
            Our Investment Services
          </h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Discover our comprehensive range of investment solutions designed to meet your financial goals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="p-6 rounded-2xl border border-slate-100 shadow-md hover:shadow-lg transition-shadow bg-white group"
            >
              <div className="p-3 rounded-lg bg-emerald-50 inline-flex mb-5 group-hover:bg-emerald-100 transition-colors">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">{service.title}</h3>
              <p className="text-slate-600 mb-5">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-slate-600">
                    <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 mr-2"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              <div className="mt-6">
                <a
                  href="#contact"
                  className="text-emerald-600 font-medium flex items-center hover:text-emerald-700 transition-colors text-sm"
                >
                  Learn more
                  <svg
                    className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M14 5l7 7m0 0l-7 7m7-7H3"
                    />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;