import React from 'react';
import { ArrowRight, TrendingUp, ShieldCheck, Award } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-32 pb-24 md:pt-40 md:pb-32 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-slate-50 to-emerald-50 z-0"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-24 right-0 w-72 h-72 bg-emerald-300 rounded-full filter blur-3xl opacity-20 z-0"></div>
      <div className="absolute bottom-12 left-12 w-64 h-64 bg-amber-300 rounded-full filter blur-3xl opacity-20 z-0"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-emerald-100 text-emerald-800 mb-6">
              <TrendingUp className="h-4 w-4 mr-2" />
              <span>Top-performing investment strategies</span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-slate-900 leading-tight">
              Invest with confidence for your{' '}
              <span className="text-emerald-600">financial future</span>
            </h1>
            <p className="mt-6 text-xl text-slate-600 max-w-2xl">
              Equinox Investments provides expert-backed investment solutions designed to help you grow your wealth, minimize risk, and secure long-term financial success.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <a
                href="#contact"
                className="px-8 py-3 rounded-lg bg-emerald-600 text-white font-medium hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-500/20 flex items-center justify-center"
              >
                Start Investing Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a
                href="#services"
                className="px-8 py-3 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-100 transition-colors flex items-center justify-center"
              >
                Explore Our Services
              </a>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative p-6 bg-white rounded-2xl shadow-xl backdrop-blur-sm bg-white/80 border border-slate-100 transform transition-all">
              <div className="absolute -top-4 -left-4 bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium">
                Featured Investment
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Global Growth Portfolio</h3>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-sm text-slate-500">Annual Return</p>
                  <p className="text-2xl font-bold text-emerald-600">+18.7%</p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Risk Level</p>
                  <p className="text-lg font-medium text-slate-700">Moderate</p>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Min Investment</p>
                  <p className="text-lg font-medium text-slate-700">$10,000</p>
                </div>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full mb-6">
                <div className="h-2 rounded-full bg-gradient-to-r from-emerald-400 to-emerald-600" style={{ width: '87%' }}></div>
              </div>
              <a
                href="#contact"
                className="block w-full py-3 rounded-lg bg-slate-800 text-white font-medium hover:bg-slate-900 transition-colors text-center"
              >
                Invest Now
              </a>
            </div>
            
            <div className="mt-8 grid grid-cols-3 gap-4">
              {[
                { icon: <TrendingUp className="h-6 w-6 text-emerald-600" />, title: 'Data-Driven', text: 'Investment decisions backed by advanced analytics' },
                { icon: <ShieldCheck className="h-6 w-6 text-emerald-600" />, title: 'Secure', text: 'Your investments protected by industry-leading security' },
                { icon: <Award className="h-6 w-6 text-emerald-600" />, title: 'Award-Winning', text: 'Recognized for excellence in financial services' },
              ].map((item, index) => (
                <div key={index} className="p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow border border-slate-100">
                  {item.icon}
                  <h4 className="mt-3 font-medium text-slate-800">{item.title}</h4>
                  <p className="mt-1 text-xs text-slate-500">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;