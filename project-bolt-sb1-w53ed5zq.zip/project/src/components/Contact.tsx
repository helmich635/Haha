import React from 'react';
import { Mail, Phone, MapPin, ArrowRight, Check } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
            Start Your Investment Journey Today
          </h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            Get in touch with our investment advisors to create a personalized strategy for your financial goals.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="bg-slate-50 rounded-2xl p-8 md:p-12">
            <h3 className="text-2xl font-bold text-slate-800 mb-6">Contact Us</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-slate-700 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-slate-700 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                />
              </div>
              
              <div>
                <label htmlFor="investmentAmount" className="block text-sm font-medium text-slate-700 mb-1">
                  Investment Amount
                </label>
                <select
                  id="investmentAmount"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                >
                  <option>Select amount</option>
                  <option>$10,000 - $50,000</option>
                  <option>$50,000 - $100,000</option>
                  <option>$100,000 - $500,000</option>
                  <option>$500,000+</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">
                  Your Investment Goals
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                  placeholder="Tell us about your investment goals and timeline..."
                ></textarea>
              </div>
              
              <div className="flex items-start">
                <input
                  id="privacy"
                  type="checkbox"
                  className="h-4 w-4 mt-1 text-emerald-600 focus:ring-emerald-500 border-slate-300 rounded"
                />
                <label htmlFor="privacy" className="ml-2 block text-sm text-slate-500">
                  I agree to the privacy policy and understand that my information will be used to contact me about investment services.
                </label>
              </div>
              
              <button
                type="submit"
                className="w-full px-6 py-3 bg-emerald-600 text-white font-medium rounded-lg hover:bg-emerald-700 transition-colors flex items-center justify-center"
              >
                Schedule a Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </form>
          </div>
          
          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-md p-6 border border-slate-100">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Why Choose Us</h3>
              <ul className="space-y-4">
                {[
                  'Personalized investment strategies tailored to your goals',
                  'Transparent fee structure with no hidden costs',
                  'Dedicated investment advisor for your portfolio',
                  'Regular performance reviews and portfolio adjustments',
                  'Access to exclusive investment opportunities',
                  'Advanced risk management and portfolio protection',
                ].map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600" />
                    </div>
                    <span className="ml-3 text-slate-600">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-slate-800 rounded-xl overflow-hidden">
              <div className="p-6 md:p-8">
                <h3 className="text-xl font-bold text-white mb-4">Get In Touch</h3>
                <div className="space-y-4 text-slate-300">
                  <div className="flex items-start">
                    <Mail className="h-5 w-5 text-emerald-400 mt-1" />
                    <div className="ml-3">
                      <p className="text-white font-medium">Email Us</p>
                      <a href="mailto:info@equinoxinvestments.com" className="hover:text-emerald-300 transition-colors">
                        info@equinoxinvestments.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-emerald-400 mt-1" />
                    <div className="ml-3">
                      <p className="text-white font-medium">Call Us</p>
                      <a href="tel:+18005551000" className="hover:text-emerald-300 transition-colors">
                        +1 (800) 555-1000
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-emerald-400 mt-1" />
                    <div className="ml-3">
                      <p className="text-white font-medium">Visit Us</p>
                      <p>
                        Equinox Tower, 123 Financial District<br />
                        New York, NY 10004
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6 md:p-8 bg-slate-700">
                <h4 className="text-lg font-medium text-white mb-3">Business Hours</h4>
                <div className="space-y-2 text-slate-300">
                  <div className="flex justify-between">
                    <span>Monday - Friday:</span>
                    <span>9:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday:</span>
                    <span>By appointment only</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday:</span>
                    <span>Closed</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-6 border border-emerald-200 rounded-xl bg-emerald-50">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-emerald-100">
                  <Phone className="h-6 w-6 text-emerald-600" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-slate-800">Prefer to talk?</h4>
                  <p className="text-slate-600">Schedule a call with an investment advisor</p>
                </div>
              </div>
              <a
                href="tel:+18005551000"
                className="mt-4 w-full inline-flex items-center justify-center px-4 py-2 border border-emerald-600 rounded-lg text-emerald-600 font-medium hover:bg-emerald-600 hover:text-white transition-colors"
              >
                Call Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;